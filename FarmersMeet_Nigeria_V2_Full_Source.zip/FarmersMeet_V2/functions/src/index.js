const {onRequest} = require('firebase-functions/v2/https');
const admin = require('firebase-admin');
const axios = require('axios');
admin.initializeApp();

exports.initializePaystack = onRequest({cors:true,secrets:['PAYSTACK_SECRET_KEY']}, async (req,res)=>{
  try {
    if(req.method !== 'POST') return res.status(405).json({error:'POST only'});
    const {email, amount, reference, metadata} = req.body;
    if(!email || !amount) return res.status(400).json({error:'email and amount required'});
    const response = await axios.post('https://api.paystack.co/transaction/initialize',
      {email, amount:String(amount), currency:'NGN', reference, metadata},
      {headers:{Authorization:`Bearer ${process.env.PAYSTACK_SECRET_KEY}`,'Content-Type':'application/json'}}
    );
    return res.json(response.data);
  } catch(e) {
    return res.status(e.response?.status || 500).json(e.response?.data || {error:e.message});
  }
});
