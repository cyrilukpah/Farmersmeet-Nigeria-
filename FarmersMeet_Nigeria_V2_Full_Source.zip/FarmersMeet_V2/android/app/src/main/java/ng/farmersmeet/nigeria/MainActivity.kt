package ng.farmersmeet.nigeria

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID

private val db = FirebaseFirestore.getInstance()
private val auth = FirebaseAuth.getInstance()
private val storage = FirebaseStorage.getInstance()
private const val PICK_IMAGE = 2001
private const val PAYSTACK_PUBLIC_KEY = "pk_test_REPLACE_ME"

data class Listing(val id:String="", val title:String="", val category:String="", val price:String="", val location:String="", val sellerId:String="", val sellerName:String="", val sellerPhone:String="", val description:String="", val imageUrl:String="", val featured:Boolean=false)

data class AppUser(val uid:String="", val name:String="", val email:String="", val phone:String="", val role:String="user")

class MainActivity : AppCompatActivity() {
    private val green=Color.rgb(23,107,58)
    private var selectedImage: Uri?=null
    private var pendingListing: MutableMap<String,Any>?=null

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); route() }

    private fun route(){ if(auth.currentUser==null) login() else home() }
    private fun base()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,20);setBackgroundColor(Color.rgb(244,248,245))}
    private fun t(s:String,z:Float=17f)=TextView(this).apply{text=s;textSize=z;setTextColor(Color.rgb(25,35,28));setPadding(0,8,0,8)}
    private fun b(s:String,a:()->Unit)=Button(this).apply{text=s;setOnClickListener{a()}}
    private fun field(h:String)=EditText(this).apply{hint=h}

    private fun login(){
        val r=base(); r.addView(t("🌱 FarmersMeet Nigeria",28f).apply{gravity=Gravity.CENTER;setTextColor(green)}); r.addView(t("Where Farmers Meet Buyers",15f))
        val email=field("Email"); val pass=field("Password"); pass.inputType=0x81; r.addView(email);r.addView(pass)
        r.addView(b("Log in"){
            auth.signInWithEmailAndPassword(email.text.toString().trim(),pass.text.toString()).addOnSuccessListener{home()}.addOnFailureListener{toast(it.message?:"Login failed")}
        })
        r.addView(b("Create new account"){signup()});r.addView(b("Forgot password"){ if(email.text.isNotBlank()) auth.sendPasswordResetEmail(email.text.toString()).addOnSuccessListener{toast("Reset email sent")}.addOnFailureListener{toast("Could not send reset email")} else toast("Enter your email first") })
        setContentView(r)
    }

    private fun signup(){
        val r=base();r.addView(t("Create FarmersMeet Account",25f));
        val name=field("Full name / business name"); val email=field("Email"); val phone=field("WhatsApp phone"); val pass=field("Password (6+ characters)");pass.inputType=0x81
        r.addView(name);r.addView(email);r.addView(phone);r.addView(pass)
        r.addView(b("Create account"){
            auth.createUserWithEmailAndPassword(email.text.toString().trim(),pass.text.toString()).addOnSuccessListener{u->
                db.collection("users").document(u.user!!.uid).set(mapOf("uid" to u.user!!.uid,"name" to name.text.toString(),"email" to email.text.toString(),"phone" to phone.text.toString(),"role" to "user" )).addOnSuccessListener{home()}
            }.addOnFailureListener{toast(it.message?:"Signup failed")}
        });r.addView(b("Back to login"){login()});setContentView(r)
    }

    private fun home(){
        val r=base();r.addView(t("🌱 FarmersMeet Nigeria",27f).apply{gravity=Gravity.CENTER;setTextColor(green)});r.addView(t("Where Farmers Meet Buyers",15f))
        val search=field("Search livestock, feeds, services...");r.addView(search);r.addView(b("Search"){loadListings(r,search.text.toString())})
        val cats=LinearLayout(this);cats.orientation=LinearLayout.VERTICAL
        listOf("Livestock","Poultry","Feeds","Veterinary Services","Equipment","Farmland","Farm Services").forEach{c->cats.addView(b(c){loadListings(r,c)})}
        r.addView(ScrollView(this).apply{addView(cats)},LinearLayout.LayoutParams(-1,230));r.addView(b("＋ Post a listing"){postListing()});r.addView(b("★ My Favorites"){favorites()});r.addView(b("💬 Messages"){messages()});r.addView(b("👤 Seller Dashboard"){sellerDashboard()});r.addView(b("⚙ Admin Dashboard"){adminDashboard()});r.addView(b("💳 Featured / Subscription"){featured()});r.addView(b("Log out"){auth.signOut();login()})
        val list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL;r.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,0,1f));loadListingsInto(list,"");setContentView(r)
    }

    private fun loadListings(r:LinearLayout,q:String){ val list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL;r.removeViews(0,r.childCount);r.addView(t("Listings",24f));r.addView(b("← Home"){home()});r.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,0,1f));loadListingsInto(list,q);setContentView(r) }

    private fun loadListingsInto(list:LinearLayout,q:String){db.collection("listings").orderBy("createdAt",Query.Direction.DESCENDING).limit(50).get().addOnSuccessListener{list.removeAllViews();for(d in it){val x=d.toObject(Listing::class.java).copy(id=d.id);if(q.isBlank()||"${x.title} ${x.category} ${x.location} ${x.sellerName}".contains(q,true))card(list,x)}}.addOnFailureListener{list.addView(t("Could not load listings: ${it.message}"))}}

    private fun card(parent:LinearLayout,x:Listing){val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(14,14,14,14);box.setBackgroundColor(Color.WHITE);box.addView(t(if(x.featured)"⭐ ${x.title}" else x.title,19f));box.addView(t(x.price,18f));box.addView(t("📍 ${x.location} • ${x.category}"));box.addView(t("Seller: ${x.sellerName}"));box.addView(t(x.description,14f));box.addView(b("♡ Favorite"){favorite(x.id)});box.addView(b("WhatsApp Seller"){whatsapp(x.sellerPhone,x.title)});box.addView(b("💬 Message Seller"){openChat(x.sellerId,x.sellerName)});parent.addView(box,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,8,0,8)})}

    private fun favorite(id:String){val uid=auth.currentUser!!.uid;db.collection("users").document(uid).collection("favorites").document(id).set(mapOf("listingId" to id,"createdAt" to System.currentTimeMillis())).addOnSuccessListener{toast("Saved to favorites")}}
    private fun favorites(){val r=base();r.addView(t("★ My Favorites",24f));r.addView(b("← Home"){home()});val list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL;r.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,0,1f));db.collection("users").document(auth.currentUser!!.uid).collection("favorites").get().addOnSuccessListener{for(f in it){db.collection("listings").document(f.id).get().addOnSuccessListener{d->if(d.exists())card(list,d.toObject(Listing::class.java)!!.copy(id=d.id))}}};setContentView(r)}

    private fun postListing(){val r=base();r.addView(t("Post a Listing",25f));val title=field("Title");val cat=field("Category");val price=field("Price in Naira");val loc=field("Location");val phone=field("WhatsApp");val desc=field("Description");listOf(title,cat,price,loc,phone,desc).forEach{r.addView(it)};r.addView(b("📷 Choose photo"){val i=Intent(Intent.ACTION_OPEN_DOCUMENT);i.type="image/*";i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_IMAGE)});r.addView(b("Publish"){
        val u=auth.currentUser!!;db.collection("users").document(u.uid).get().addOnSuccessListener{ud->
            val data=mutableMapOf<String,Any>("title" to title.text.toString(),"category" to cat.text.toString(),"price" to price.text.toString(),"location" to loc.text.toString(),"sellerId" to u.uid,"sellerName" to (ud.getString("name")?:u.email.orEmpty()),"sellerPhone" to phone.text.toString(),"description" to desc.text.toString(),"featured" to false,"createdAt" to System.currentTimeMillis())
            selectedImage?.let{uri->val ref=storage.reference.child("listingImages/${u.uid}/${UUID.randomUUID()}");ref.putFile(uri).continueWithTask{ref.downloadUrl}.addOnSuccessListener{url->data["imageUrl"]=url.toString();saveListing(data)} } ?: saveListing(data)
        }
    });r.addView(b("Cancel"){home()});setContentView(r)}

    private fun saveListing(data:MutableMap<String,Any>){db.collection("listings").add(data).addOnSuccessListener{toast("Listing published");home()}.addOnFailureListener{toast(it.message?:"Could not publish")}}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==PICK_IMAGE&&resultCode==Activity.RESULT_OK){selectedImage=data?.data}}

    private fun whatsapp(phone:String,title:String){val n=phone.replace(Regex("\\D"),"").let{if(it.startsWith("0"))"234"+it.drop(1) else it};startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/$n?text="+Uri.encode("Hello, I saw your FarmersMeet listing: $title"))))}

    private fun openChat(otherId:String,otherName:String){val r=base();r.addView(t("💬 Chat with $otherName",24f));val messagesBox=LinearLayout(this);messagesBox.orientation=LinearLayout.VERTICAL;val input=field("Message...");r.addView(ScrollView(this).apply{addView(messagesBox)},LinearLayout.LayoutParams(-1,0,1f));r.addView(input);r.addView(b("Send"){val sender=auth.currentUser!!.uid;val chatId=listOf(sender,otherId).sorted().joinToString("_");db.collection("chats").document(chatId).collection("messages").add(mapOf("senderId" to sender,"text" to input.text.toString(),"createdAt" to System.currentTimeMillis()));input.text.clear()});r.addView(b("← Home"){home()});db.collection("chats").document(listOf(auth.currentUser!!.uid,otherId).sorted().joinToString("_")).collection("messages").orderBy("createdAt").addSnapshotListener{snap,e->messagesBox.removeAllViews();snap?.forEach{messagesBox.addView(t(it.getString("text")?:""))}};setContentView(r)}
    private fun messages(){toast("Messaging is available from a listing")}

    private fun sellerDashboard(){val r=base();r.addView(t("Seller Dashboard",25f));r.addView(b("← Home"){home()});val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;r.addView(box);db.collection("listings").whereEqualTo("sellerId",auth.currentUser!!.uid).get().addOnSuccessListener{box.addView(t("Your listings: ${it.size()}"));it.forEach{d->box.addView(t("• ${d.getString("title")?:"Listing"} — ${d.getString("price")?:""}"))}};r.addView(b("＋ New listing"){postListing()});setContentView(r)}

    private fun featured(){val r=base();r.addView(t("⭐ Featured Listings",25f));r.addView(t("Pay to move your listing to featured positions."));r.addView(b("₦5,000 — 7 days"){startPayment(500000,"Featured listing")});r.addView(b("₦15,000 — Monthly seller plan"){startPayment(1500000,"Monthly seller plan")});r.addView(b("← Home"){home()});setContentView(r)}

    private fun startPayment(amountKobo:Int,label:String){toast("Payment setup requires your backend access code. $label selected: ₦${amountKobo/100}")}

    private fun adminDashboard(){val r=base();r.addView(t("Admin Dashboard",25f));r.addView(t("This screen is protected by the users/{uid}.role == admin Firestore rule."));r.addView(b("Pending reports"){db.collection("reports").whereEqualTo("status","pending").get().addOnSuccessListener{toast("Pending reports: ${it.size()}")}});r.addView(b("All listings"){db.collection("listings").get().addOnSuccessListener{toast("Listings: ${it.size()}")}});r.addView(b("All users"){db.collection("users").get().addOnSuccessListener{toast("Users: ${it.size()}")}});r.addView(b("← Home"){home()});setContentView(r)}
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
}
