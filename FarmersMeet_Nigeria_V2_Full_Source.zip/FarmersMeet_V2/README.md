# FarmersMeet Nigeria — Version 2

Android/Kotlin + Firebase + Paystack backend starter.

## Included
- Email/password login and signup
- Firestore user profiles
- Listings stored in Firestore
- Photo selection + Firebase Storage upload
- Favorites
- Seller dashboard
- Basic Firestore chat/messages
- Featured/subscription screen
- Admin dashboard skeleton
- Paystack initialization Cloud Function (secret key stays server-side)

## Firebase setup
1. Create a Firebase project.
2. Add an Android app with package `ng.farmersmeet.nigeria`.
3. Download `google-services.json` into `android/app/`.
4. Enable Email/Password Authentication.
5. Create Firestore Database.
6. Create Storage.
7. Deploy `firestore.rules` and `storage.rules` with Firebase CLI.
8. Create your first admin user, then set that user's Firestore `role` to `admin` using the Firebase console.

## Paystack
Paystack's current Android documentation says payment initialization must happen on a server because it uses the secret key. This project therefore puts initialization in a Firebase HTTPS function. Add the Paystack secret as a Firebase Secret named `PAYSTACK_SECRET_KEY`; never put it in the Android app.

The Android payment screen is intentionally a safe placeholder until the function URL and public key are configured. Replace `pk_test_REPLACE_ME` in `MainActivity.kt` with your Paystack public key only after configuring your Paystack account.

## Build
Open `android/` in Android Studio and build the debug APK, or run:
`gradle assembleDebug`

## Important production work still needed
- Server-side authorization for chat participants
- Better Firestore chat membership rules
- Image thumbnails/compression
- Report/block flows
- Payment verification/webhooks before granting featured status
- Seller verification/KYC policy
- Admin moderation UI
- Pagination and indexes
- Privacy policy/terms
- App signing and Play Store release
